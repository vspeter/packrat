#!/usr/bin/env python3

import glob
from distutils.core import setup
from distutils.command.build_py import build_py
from setuptools import find_packages
import os


setup( name='pytest',
       description='pyTest',
       author='Peter Howe',
       author_email='peter.howe@virtustream.com',
       include_package_data=True,
       packages=[ '.' ],
       )
